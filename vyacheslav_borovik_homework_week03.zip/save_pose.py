import maya.cmds as cmds
import json 

json_path = "D:/Scripts/03/poses"
poseName = "Pose4"
jsonData = {}

# get all controls in rig 
def getControls(rig = "zoma_base_rig"):

    # approach getting all children is not good because rigs usually contain a lot of stuff which is not used for animation, and some curves could be hidden on purpose for not being modified or touched.
    # Usually for pose transfering visible curves are used, selected in viewport or by pre-made selection sets

    # children = cmds.listRelatives(rig, children = 1, fullPath = 1, allDescendents = 1)
    # controls = []
    # for i in children:
    #     if cmds.nodeType(i) == "nurbsCurve":
    #         transform = cmds.listRelatives(i, parent = 1, fullPath =1)[0]
    #         controls.append(transform)
    #         print transform


    selectedObjects = cmds.ls(sl=1, l = 0)
    if selectedObjects:
        controls = []
        for i in selectedObjects:

            # childObj = cmds.listRelatives(i, children = 1)[0]
            # if cmds.nodeType(childObj) == "nurbsCurve":
                # controls.append(i)
                # jsonData[i] = []
        
            # !!! this rig is weird and has curves with objects type "joints", so I added all selected objects to a controls without checking is it a curve o not, just by selecting curves only
            controls.append(i)
            jsonData[i] = {}

    else:
        cmds.error("please select controls")

    return controls


def write_json(path, name):
    with open (path + "/" + name + ".json", "w") as f:
        f.write(json.dumps(jsonData, indent = 4, sort_keys = True))


def main():

    controls = getControls()

    # get list of keyable channels and add control to a json
    for ctrl in controls:
        jsonData[ctrl] = {}
        channels = cmds.listAttr(ctrl, keyable=1)

        # write down the value of a particular channel and add it to a json
        # fix issue with channels type none
        if channels:
            for ch in channels:
                jsonData[ctrl][ch] = cmds.getAttr(ctrl + "." + ch)
        else:
            continue

    write_json (path = json_path, name = poseName)

main ()

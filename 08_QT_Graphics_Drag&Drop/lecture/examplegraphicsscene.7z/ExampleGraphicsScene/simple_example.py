import maya.cmds as cmds
from PySide2 import QtWidgets, QtCore, QtGui


class MyGraphicsScene(QtWidgets.QDialog):
    def __init__(self):
        super(MyGraphicsScene, self).__init__()

        self.setFixedSize(800,800)
        self.setObjectName("MyGraphicsSceneIDHAHA")
        self.setWindowTitle("My Graphcis Scene")


        self.main_layout = QtWidgets.QVBoxLayout()
        self.setLayout(self.main_layout)


        self.viewport = QtWidgets.QGraphicsView()
        self.main_layout.addWidget(self.viewport)

        self.scene = QtWidgets.QGraphicsScene()
        self.viewport.setScene(self.scene)

        self.penRed = QtGui.QPen(QtCore.Qt.red)
        self.brushGreen = QtGui.QBrush(QtCore.Qt.green)
        self.brushBlue = QtGui.QBrush(QtCore.Qt.blue)

        ellipse = self.scene.addEllipse(20,20,200,200, self.penRed, self.brushGreen)

        rectangle = self.scene.addRect(-300, -300, 200, 200, self.penRed, self.brushBlue)

        ellipse.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable)
        rectangle.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable)

        ellipse.setZValue(2)
        rectangle.setZValue(1)



def main():

    if cmds.window("MyGraphicsSceneIDHAHA", exists=1):
        cmds.deleteUI("MyGraphicsSceneIDHAHA")

    if cmds.windowPref("MyGraphicsSceneIDHAHA", exists=1):
        cmds.windowPref("MyGraphicsSceneIDHAHA", remove=1)

    global afasdfasd


    afasdfasd = MyGraphicsScene()
    afasdfasd.show()


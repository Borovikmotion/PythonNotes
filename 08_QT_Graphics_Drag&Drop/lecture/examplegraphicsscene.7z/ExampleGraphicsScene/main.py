import maya.cmds as cmds
from PySide2 import QtWidgets, QtCore, QtGui
from view import View
from scene import Scene


class MyGraphicsScene(QtWidgets.QDialog):
    def __init__(self):
        super(MyGraphicsScene, self).__init__()

        self.setMinimumSize(800,800)
        self.setObjectName("MyGraphicsSceneIDHAHA")
        self.setWindowTitle("My Graphcis Scene")


        self.main_layout = QtWidgets.QVBoxLayout()
        self.main_layout.setContentsMargins(0,0,0,0)
        self.setLayout(self.main_layout)


        self.viewport = View()
        self.main_layout.addWidget(self.viewport)

        self.scene = Scene()
        self.viewport.setScene(self.scene)

        self.scene.selectionChanged.connect(self.on_change_selection)

    def on_change_selection(self):
        
        self.scene.define_selection()




def main():

    if cmds.window("MyGraphicsSceneIDHAHA", exists=1):
        cmds.deleteUI("MyGraphicsSceneIDHAHA")

    if cmds.windowPref("MyGraphicsSceneIDHAHA", exists=1):
        cmds.windowPref("MyGraphicsSceneIDHAHA", remove=1)

    global afasdfasd


    afasdfasd = MyGraphicsScene()
    afasdfasd.show()


from PySide2 import QtWidgets, QtGui, QtCore

import maya.cmds as cmds


class Curve(QtWidgets.QGraphicsLineItem):

    def __init__(self, circleA, circleB):

        super(Curve, self).__init__()

        self.curve_points = [circleA, circleB]


        # self.curve_points = sorted(self.curve_points, key=lambda item: item.pos().x())

        self.pen_color = QtGui.QPen((QtGui.QColor(144, 245, 153, 255)), 2, QtCore.Qt.SolidLine)


        self.setZValue(10)
        self.setVisible(True)

    def paint(self, painter, QStyleOptionGraphicsItem, widget=None):

        # self.curve_points = sorted(self.curve_points, key=lambda item: item.pos().x())

        #* Brush & Pen
        painter.setPen(self.pen_color)

        #* Line        
        self.path = QtGui.QPainterPath(self.curve_points[0].pos())

        for i in range(len(self.curve_points)-1):
            # self.path.lineTo(self.curve_points[i].pos())
            distance = self.curve_points[i+1].pos().x() - self.curve_points[i].pos().x()
            cubic_distance = distance/2
            cubic_point_a = QtCore.QPointF(self.curve_points[i].pos().x() + cubic_distance, self.curve_points[i].pos().y())
            cubic_point_b = QtCore.QPointF(self.curve_points[i+1].pos().x() - cubic_distance, self.curve_points[i+1].pos().y())
            end_point = self.curve_points[i+1].pos()
            self.path.cubicTo(cubic_point_a, cubic_point_b, end_point)

        painter.drawPath(self.path)





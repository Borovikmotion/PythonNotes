from PySide2 import QtWidgets, QtCore, QtGui


class Line(QtWidgets.QGraphicsLineItem):
    def __init__(self, circleA=None, circleB=None):
        super(Line, self).__init__()

        self.pen = QtGui.QPen(QtGui.QColor(242, 86, 51, 255), 5, QtCore.Qt.SolidLine)
        self.setPen(self.pen)

        self.circleA = circleA
        self.circleB = circleB

        circlePosA = self.circleA.scenePos()
        circlePosB = self.circleB.scenePos()
        self.setLine(circlePosA.x(), circlePosA.y(), circlePosB.x(), circlePosB.y())


    def paint(self, painter, QStyleOptionGraphicsItem, widget=None):

        super(Line, self).paint(painter, QStyleOptionGraphicsItem, widget)

        circlePosA = self.circleA.scenePos()
        circlePosB = self.circleB.scenePos()
        self.setLine(circlePosA.x(), circlePosA.y(), circlePosB.x(), circlePosB.y())
    

    



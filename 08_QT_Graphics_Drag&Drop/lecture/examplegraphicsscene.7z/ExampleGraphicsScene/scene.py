from PySide2 import QtWidgets, QtCore, QtGui
import maya.cmds as cmds
from item_circle import Circle
from item_line import Line
from item_curve import Curve
# from item_group import Group

class Scene(QtWidgets.QGraphicsScene):
    def __init__(self):
        super(Scene, self).__init__()

        self.selected_object = []

        self.circleA = Circle()
        self.circleA.selection_object = "pSphere1"
        self.addItem(self.circleA)

        self.circleB = Circle()
        self.circleB.moveBy(100, 0)
        self.circleB.selection_object = "pSphere2"
        self.addItem(self.circleB)

        self.line = Curve(self.circleA, self.circleB)
        self.addItem(self.line)

        # self.group = Group()
        # self.addItem(self.group)


    def define_selection(self):

        
        for i in self.selected_object:
            i.set_unselected()

        self.selected_object = self.selectedItems()

        for i in self.selected_object:
            i.set_selected()

            cmds.select(i.selection_object)


    def mouseMoveEvent(self, event):

        super(Scene, self).mouseMoveEvent(event)

        pos = event.scenePos()

        for i in self.selected_object:

            maya_object  = i.selection_object

            if not cmds.objExists(maya_object):
                continue

            coord_x = pos.x() / float(10)
            coord_y = pos.y() / float(10)

            cmds.xform(maya_object, t=[coord_x, coord_y, 0], a=1)

        self.update()




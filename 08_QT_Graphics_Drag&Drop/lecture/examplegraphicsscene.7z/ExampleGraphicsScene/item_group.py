from PySide2 import QtWidgets, QtCore, QtGui
from item_circle import Circle

class Group(QtWidgets.QGraphicsItemGroup):
    def __init__(self, name = "No Name"):
        super(Group, self).__init__()

        self.setFlags(QtWidgets.QGraphicsItemGroup.ItemIsMovable | QtWidgets.QGraphicsItemGroup.ItemIsSelectable)

        self.circleA = Circle()
        self.circleA.selection_object = "pSphere1"
        self.addToGroup(self.circleA)

        self.circleB = Circle()
        self.circleB.moveBy(200, 0)
        self.circleB.selection_object = "pSphere2"
        self.addToGroup(self.circleB)





    def paint(self, painter, QStyleOptionGraphicsItem, widget=None):
        painter.setPen(QtCore.Qt.NoPen)




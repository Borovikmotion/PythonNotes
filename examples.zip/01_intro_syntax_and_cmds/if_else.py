""" IF ELSE  """
a = 2
if a==3 and a>0:
    print "yes"
else:
    print "no"

> < >= <= != 
and or 
(...or...) and 
(...or...) and: if True and True 


""" if not ==  """
a = 2
if a==3:
    print "3"
elif a==4:
    print "4"
elif a==10:
    print "10"
else:
    print "no"

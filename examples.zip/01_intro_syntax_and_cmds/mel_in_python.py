""" как запустить мел скрипт через питон """
import maya.cmds as cmds
import maya.mel
maya.mel.eval("polySphere -r 1 -n MyS")

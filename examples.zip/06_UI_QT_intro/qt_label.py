        # label
        self.text  = "hello world"
        self.label_ = QtWidgets.QLabel(self.text)
        self.main_layout.addWidget(self.label_)
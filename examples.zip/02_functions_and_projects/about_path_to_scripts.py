
# this PC - documents - maya
# maya.env
PYTHONPATH = ""
# to google - maya file path variables

import myScript
myScript.main()
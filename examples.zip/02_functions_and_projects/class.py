""" CLASSES """
class A:
    def __init__(self):
        self.a=1
        self.b=2

x = A()
y = A()

print x, y 

d = {"pSphere1":x, "pSphere2":y}
# 1 put some functions like load json etc. into a separate moddule like utils.py

